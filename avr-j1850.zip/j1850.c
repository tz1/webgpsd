#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/wdt.h>
#include <string.h>

#define bSDA        (1<<5)
#define bSCL        (1<<7)

unsigned char txhead = 0, txmark = 0,  txtail = 0;
#define TXBSZ 128
unsigned char txbuf[TXBSZ];// = {7,0x22,0x44,0x66,0x88,0xaa,0xcc,0xee};
static volatile unsigned char step;

#define BASECLRST  ((1 << USIOIF) | (1 << USIPF) | (1 << USIDC))
#define STARTMODE ((1 << USISIE) | (1 << USIWM1) | (1 << USICS1))

/*------------------------------------------------------------------------*/
/* USI ISRs, start and overflow */

ISR(USI_START_vect)
{
    DDRB &= ~bSDA;
    //    sei();
    while ((PINB & (bSCL | bSDA)) == bSCL)        // wait for SCL down
        ;                      //DO SOMETHING WHILE WAITING?
    step = 0;
    // if SDA goes up it is a stop
    USICR = STARTMODE | (PINB & bSDA ? 0 : (1 << USIOIE) | (1 << USIWM0));
    USISR = (1 << USISIF) | BASECLRST;
}

ISR(USI_OVERFLOW_vect)
{
    switch (step++) {
    case 0: // start, Address sent
        if (txhead == txtail || USIDR != 0x55)
            break;
	wdt_reset();
        DDRB |= bSDA; // set to output
        USIDR = 0; // ACK from slave
        USISR = BASECLRST | (0x0E << USICNT0);
        return;
    case 3: // get NAK or ACK from sent data byte
        if (USIDR)              // NAK from master, End of transaction
            break;
	if( txhead == txtail || txbuf[txtail] == 'J' )
	    break;
	// fallthrough
    case 1: // send data byte
        // TODO if step == 2, length, if step == 4, data 
        if (txhead == txtail) // no more data, send 0xffs
	    break;
	USIDR = txbuf[txtail++];
	if( txtail >= TXBSZ )
	    txtail = 0;
        DDRB |= bSDA; // set to transmit byte
        USISR = BASECLRST;
        step = 2;               // rewind to ack read from master step
        return;
    case 2: // Byte sent, turn around to get ACK
        USIDR = 0;              // clear to receive ACK
        DDRB &= ~bSDA;          // input for ACK 
        USISR = BASECLRST | (0x0E << USICNT0);
        return;
    default:
        break;
    }
    step = 99;
    USICR = STARTMODE;
    USISR = BASECLRST;
}

/*------------------------------------------------------------------------*/
// Main Timer : j1850
#define EBL (16)
unsigned char edgebuf[EBL];
unsigned char edgeptrh = 0, edgeptrt = 0;

ISR(TIMER1_COMPA_vect) // EOD timeout
{
    TIMSK &= ~0x40;             // self disable
    unsigned tc = TCNT1;
    unsigned *ep;
    // insert zero len pulse as marker
    ep = (unsigned *) &edgebuf[edgeptrh];
    edgeptrh += 4;
    edgeptrh &= EBL - 1;
    *ep++ = tc;
    *ep = tc;
}

ISR(TIMER1_CAPT_vect) // Edge - switch polarity, save time into buffer
{
    TCCR1B ^= 0x40;
    unsigned *ep = (unsigned *) &edgebuf[edgeptrh];
    edgeptrh += 2;
    edgeptrh &= EBL - 1;
    *ep = ICR1;
    OCR1A = *ep++ + 250;        // timeout - EOD
    TIFR |= 0x40;               // clear any accumulated interrupts
    TIMSK |= 0x40;              // enable OC interrupt for EOD
}

int main(void)
{
    unsigned char jbitaccum = 0, jbitcnt = 0, polarity = 0;
    unsigned lastedge = 0;

    MCUSR &= ~(1<<WDRF);
    wdt_reset();
    WDTCR |= (1<<WDCE) | (1<<WDE);
    WDTCR = (1<<WDE) | (1<<WDP3) | (1<<WDP0); // 8 Seconds

    // Select clock, etc for timer |1 = xtal/1, |2 = xtal/8,,,
    GTCCR = 0x81;               // stop for reset - normally to sync multiples
    TCNT1 = 0;
    TCCR1B = 0xC0 | 2;          // NoiseC, edge ...  off,1,8,64,256,1024,ext
    GTCCR = 0x80;               // start

    TIFR |= 0x8;                // reset interrupt triggers
    TIMSK |= 0x8;               // enable interrupt

    DDRB |= bSCL | bSDA;
    PORTB |= bSCL;
    PORTB |= bSDA;
    DDRB &= ~bSDA; // SDA as input
    USICR = STARTMODE;
    USISR = USISIF | BASECLRST;

    sei();

    for (;;) {
        sleep_mode();           // INT will waken
        while (edgeptrh != edgeptrt) {
            unsigned *lep, width;
            lep = (unsigned *) &edgebuf[edgeptrt];
            edgeptrt += 2;
            edgeptrt &= EBL - 1;
            width = *lep - lastedge;
            lastedge = *lep;
            polarity ^= 1;

            if (!width && txmark != txhead) {       // EOD indicator from OC - only when message is in buffer
		txbuf[txmark++] = '\n';
		if( txmark >= TXBSZ )
		    txmark = 0;
		txhead = txmark; // set chars to Tx
                continue;       // EOF/EOD
            }

            // bad width or outside, will happen at EOD
	    // TODO? send any message (same as !width) or send other indication?
            if (width > 240 || width < 32) {
                jbitcnt = jbitaccum = 0;
                continue;
            }

            // doesn't quite do IFRs - normalization bit, crc?
            if (!polarity && width > 165) {     //SOF
		// start, reserve length, set marker
	        txbuf[txhead] = 'J';
		txmark = txhead + 1;
		if( txmark >= TXBSZ )
		    txmark = 0;
                jbitcnt = jbitaccum = 0;
                continue;
            }

	    // append next bit
            jbitaccum <<= 1;
            if ((width < 96) ^ polarity)
                jbitaccum++;
            if (++jbitcnt < 4)
                continue;
            //while( !(UCSRA & 0x20));
	    txbuf[txmark++] = jbitaccum > 9 ? 'A' - 10 + jbitaccum : '0' + jbitaccum;
	    if( txmark >= TXBSZ )
		txmark = 0;
            jbitcnt = jbitaccum = 0;
        }
    }
}
